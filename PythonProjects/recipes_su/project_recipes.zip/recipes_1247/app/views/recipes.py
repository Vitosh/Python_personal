from django.shortcuts import render, redirect

from app.forms.recipes import RecipeForm, DeleteRecipeForm
from app.models import Recipe


def recipe_create(request):
    if request.method == 'GET':
        context = {
            'form': RecipeForm(),
        }
        return render(request, 'create.html', context)
    else:
        form = RecipeForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return redirect('index')
        context = {
            'form': form,
        }
        return render(request, 'create.html', context)


def recipe_edit(request, pk):
    recipe = Recipe.objects.get(pk=pk)

    if request.method == 'GET':
        context = {
            'recipe': recipe,
            'form': RecipeForm(instance=recipe)
        }
        return render(request, 'edit.html', context)
    else:
        form = RecipeForm(request.POST, instance=recipe)
        if form.is_valid():
            form.save()
            return redirect('index')

        context = {
            'recipe': recipe,
            'form': form,
        }
        return render(request, 'edit.html', context)


def recipe_details(request, pk):
    recipe = Recipe.objects.get(pk=pk)
    ingredients = recipe.ingredients.split(', ')
    context = {
        'recipe': recipe,
        'ingredients': ingredients,
    }
    return render(request, 'details.html', context)


def recipe_delete(request, pk):
    recipe = Recipe.objects.get(pk=pk)

    if request.method == 'GET':
        context = {
            'recipe': recipe,
            'form': DeleteRecipeForm(instance=recipe)
        }

        return render(request, 'delete.html', context)
    else:
        recipe.delete()
        return redirect('index')
