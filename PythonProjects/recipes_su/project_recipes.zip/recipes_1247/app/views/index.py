from django.shortcuts import render

from app.models import Recipe


def index(request):

    recipes_present = Recipe.objects.exists()
    recipes = Recipe.objects.all()

    context = {
        'recipes_present': recipes_present,
        'recipes': recipes,
    }

    return render(request, 'index.html', context)

